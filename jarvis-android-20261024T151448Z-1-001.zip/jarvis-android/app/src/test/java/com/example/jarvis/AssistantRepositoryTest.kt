package com.example.jarvis

import com.example.jarvis.data.AssistantRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class AssistantRepositoryTest {
    @Test fun rejectsMissingEndpointWithActionableConfigurationMessage() = runBlocking {
        val error = assertThrows(IllegalStateException::class.java) {
            runBlocking { AssistantRepository("").reply(listOf("user" to "Olá")) }
        }
        assertEquals("Configure a URL HTTPS do backend em Configurações.", error.message)
    }

    @Test fun rejectsPlainHttpEndpoint() = runBlocking {
        val error = assertThrows(IllegalStateException::class.java) {
            runBlocking { AssistantRepository("http://localhost:8787").reply(listOf("user" to "Olá")) }
        }
        assertEquals("Configure a URL HTTPS do backend em Configurações.", error.message)
    }
}
