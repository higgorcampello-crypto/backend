package com.example.jarvis.data

import java.io.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AssistantRepository(private val baseUrl: String) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS).readTimeout(45, TimeUnit.SECONDS).build()

    suspend fun reply(history: List<Pair<String, String>>): String = withContext(Dispatchers.IO) {
        val endpoint = baseUrl.trim().trimEnd('/')
        if (endpoint.isBlank() || !endpoint.startsWith("https://")) {
            throw IllegalStateException("Configure a URL HTTPS do backend em Configurações.")
        }
        val messages = JSONArray().apply {
            history.takeLast(20).forEach { (role, text) ->
                put(JSONObject().put("role", role).put("content", text))
            }
        }
        val body = JSONObject().put("messages", messages).toString()
            .toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder().url("$endpoint/chat").post(body).build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val message = try { JSONObject(raw).optString("error") } catch (_: Exception) { "" }
                throw IOException(message.ifBlank { "Backend indisponível (HTTP ${response.code})." })
            }
            val answer = JSONObject(raw).optString("reply").trim()
            if (answer.isBlank()) throw IOException("O backend retornou uma resposta vazia.")
            answer
        }
    }
}
