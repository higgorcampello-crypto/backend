package com.example.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.animation.core.tween
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.jarvis.data.AssistantRepository
import java.util.Locale
import kotlinx.coroutines.launch

private val Cyan = Color(0xFF42E8FF)
private val Background = Color(0xFF060B12)
private enum class UiMode { IDLE, LISTENING, PROCESSING, SPEAKING, ERROR }
private data class Line(val role: String, val text: String)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var onRecognized: ((String) -> Unit)? = null
    private var onSpeechEnd: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            JarvisScreen(
                beginListening = { result, end -> startRecognition(result, end) },
                stopListening = { stopRecognition() },
                speak = { text, end -> speak(text, end) },
                stopSpeaking = { stopSpeech() },
                hasAudioPermission = { ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED }
            )
        }
    }
    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            val result = tts?.setLanguage(Locale("pt", "BR"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) ttsReady = false
        }
    }
    private fun startRecognition(onResult: (String) -> Unit, onEnd: () -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { onEnd(); return }
        onRecognized = onResult; onSpeechEnd = onEnd
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { speech ->
            speech.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) = Unit
                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() = Unit
                override fun onEvent(eventType: Int, params: Bundle?) = Unit
                override fun onPartialResults(partialResults: Bundle?) = Unit
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!text.isNullOrBlank()) onRecognized?.invoke(text) else onSpeechEnd?.invoke()
                }
                override fun onError(error: Int) { onSpeechEnd?.invoke() }
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale sua mensagem")
            }
            speech.startListening(intent)
        }
    }
    private fun stopRecognition() { recognizer?.cancel(); recognizer?.destroy(); recognizer = null; onSpeechEnd?.invoke() }
    private fun speak(text: String, end: () -> Unit) {
        if (!ttsReady || tts == null) { end(); return }
        tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) { runOnUiThread { end() } }
            @Deprecated("Deprecated in Java") override fun onError(utteranceId: String?) { runOnUiThread { end() } }
        })
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-${System.currentTimeMillis()}")
    }
    private fun stopSpeech() { tts?.stop() }
    override fun onDestroy() { stopRecognition(); tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun JarvisScreen(
    beginListening: ((String) -> Unit, () -> Unit) -> Unit,
    stopListening: () -> Unit,
    speak: (String, () -> Unit) -> Unit,
    stopSpeaking: () -> Unit,
    hasAudioPermission: () -> Boolean
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("jarvis", android.content.Context.MODE_PRIVATE) }
    var saveHistory by remember { mutableStateOf(prefs.getBoolean("save_history", false)) }
    var endpoint by remember { mutableStateOf(prefs.getString("backend_url", "") ?: "") }
    var lines by remember { mutableStateOf(if (saveHistory) loadLines(prefs.getString("history", "[]") ?: "[]") else emptyList()) }
    var draft by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(UiMode.IDLE) }
    var status by remember { mutableStateOf("SISTEMA PRONTO · SEM GRAVAÇÃO EM SEGUNDO PLANO") }
    var showSettings by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val repository = remember(endpoint) { AssistantRepository(endpoint) }
    fun persist(items: List<Line>) { if (saveHistory) prefs.edit().putString("history", org.json.JSONArray().apply { items.forEach { put(org.json.JSONObject().put("role", it.role).put("text", it.text)) } }.toString()).apply() }
    fun submit(text: String) {
        val clean = text.trim(); if (clean.isEmpty() || mode == UiMode.PROCESSING) return
        draft = ""; val current = lines + Line("user", clean); lines = current; persist(current)
        mode = UiMode.PROCESSING; status = "PROCESSANDO SOLICITAÇÃO"
        scope.launch {
            try {
                val answer = repository.reply(current.map { it.role to it.text })
                val updated = lines + Line("assistant", answer); lines = updated; persist(updated)
                mode = UiMode.SPEAKING; status = "RESPOSTA EM VOZ · TOQUE EM PARAR PARA INTERROMPER"
                speak(answer) { if (mode == UiMode.SPEAKING) { mode = UiMode.IDLE; status = "SISTEMA PRONTO" } }
            } catch (e: Exception) {
                mode = UiMode.ERROR; status = e.message ?: "Falha de conexão. Verifique internet e backend."
            }
        }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { mode = UiMode.LISTENING; status = "ESCUTANDO · FALE AGORA"; beginListening({ result -> mode = UiMode.IDLE; submit(result) }, { if (mode == UiMode.LISTENING) { mode = UiMode.ERROR; status = "Não foi possível reconhecer a fala. Tente novamente." } }) }
        else { mode = UiMode.ERROR; status = "Permissão de microfone negada. Você ainda pode digitar." }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Background, surface = Color(0xFF101923))) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF081521), Background, Color(0xFF03060A))).padding(horizontal = 18.dp, vertical = 12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column { Text("J.A.R.V.I.S.", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp); Text("ASSISTENTE DE INTERFACE", color = Color.LightGray, fontSize = 9.sp, letterSpacing = 2.sp) }
                TextButton(onClick = { showSettings = true }) { Text("CONFIG", color = Cyan, fontSize = 11.sp) }
            }
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().weight(0.34f), contentAlignment = Alignment.Center) { Core(mode) }
            Text(status.uppercase(), Modifier.fillMaxWidth(), color = if (mode == UiMode.ERROR) Color(0xFFFF7B7B) else Cyan, fontSize = 10.sp, letterSpacing = 1.2.sp)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(0.52f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (lines.isEmpty()) item { Text("Histórico vazio. Configure o backend ou envie uma mensagem.", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(vertical = 12.dp)) }
                items(lines) { line ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.role == "user") Arrangement.End else Arrangement.Start) {
                        Surface(color = if (line.role == "user") Color(0xFF123747) else Color(0xFF121C25), shape = RoundedCornerShape(14.dp)) {
                            Column(Modifier.widthIn(max = 300.dp).padding(12.dp)) {
                                Text(if (line.role == "user") "VOCÊ" else "J.A.R.V.I.S.", color = Cyan, fontSize = 9.sp, letterSpacing = 1.3.sp)
                                Spacer(Modifier.height(4.dp)); Text(line.text, color = Color.White, fontSize = 14.sp)
                            }
                        }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f), placeholder = { Text("Digite em português…", color = Color.Gray) }, keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences), singleLine = false, maxLines = 3, shape = RoundedCornerShape(18.dp))
                IconButton(onClick = { submit(draft) }, enabled = mode != UiMode.PROCESSING && draft.isNotBlank()) { Icon(Icons.Default.Send, "Enviar mensagem", tint = Cyan) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = {
                    if (mode == UiMode.LISTENING) { stopListening(); mode = UiMode.IDLE; status = "RECONHECIMENTO CANCELADO" }
                    else if (mode == UiMode.SPEAKING) { stopSpeaking(); mode = UiMode.IDLE; status = "FALA INTERROMPIDA" }
                    else if (hasAudioPermission()) { mode = UiMode.LISTENING; status = "ESCUTANDO · FALE AGORA"; beginListening({ text -> mode = UiMode.IDLE; submit(text) }, { if (mode == UiMode.LISTENING) { mode = UiMode.ERROR; status = "Não foi possível reconhecer a fala." } }) }
                    else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0B3443))) {
                    Icon(if (mode == UiMode.LISTENING) Icons.Default.Stop else if (mode == UiMode.SPEAKING) Icons.Default.Stop else Icons.Default.Mic, null); Spacer(Modifier.width(8.dp)); Text(when (mode) { UiMode.LISTENING -> "CANCELAR ESCUTA"; UiMode.SPEAKING -> "PARAR FALA"; else -> "FALAR" })
                }
                TextButton(onClick = { lines = emptyList(); prefs.edit().remove("history").apply(); status = "HISTÓRICO APAGADO NESTE DISPOSITIVO" }) { Text("LIMPAR", color = Color.Gray, fontSize = 10.sp) }
            }
        }
    }
    if (showSettings) AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("Configurações e privacidade", color = Cyan) }, text = {
        Column {
            Text("URL HTTPS do backend (sem chave de API):", color = Color.White, fontSize = 12.sp)
            OutlinedTextField(endpoint, { endpoint = it }, placeholder = { Text("https://seu-servidor.example") }, singleLine = true)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(saveHistory, { checked -> saveHistory = checked; prefs.edit().putBoolean("save_history", checked).apply(); if (!checked) { prefs.edit().remove("history").apply(); lines = emptyList() } else persist(lines) })
                Text("Salvar histórico localmente neste aparelho", color = Color.White, fontSize = 12.sp)
            }
            Text("A chave do modelo deve existir somente no servidor. Desative o histórico para não persistir conversas.", color = Color.LightGray, fontSize = 11.sp)
        }
    }, confirmButton = { TextButton(onClick = { prefs.edit().putString("backend_url", endpoint.trim()).apply(); showSettings = false }) { Text("SALVAR", color = Cyan) } }, dismissButton = { TextButton(onClick = { showSettings = false }) { Text("FECHAR") } })
}

@Composable
private fun Core(mode: UiMode) {
    val transition = androidx.compose.animation.core.rememberInfiniteTransition(label = "core")
    val pulse by transition.animateFloat(initialValue = 0.88f, targetValue = 1.12f, animationSpec = androidx.compose.animation.core.infiniteRepeatable(tween(1300), androidx.compose.animation.core.RepeatMode.Reverse), label = "pulse")
    val tint = when (mode) { UiMode.ERROR -> Color(0xFFFF5151); UiMode.LISTENING -> Color(0xFF48FFD0); UiMode.PROCESSING -> Color(0xFF70A7FF); UiMode.SPEAKING -> Color(0xFFFFB84D); UiMode.IDLE -> Cyan }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size((142 * pulse).dp).shadow(24.dp, CircleShape, ambientColor = tint, spotColor = tint).background(Brush.radialGradient(listOf(tint.copy(alpha = .52f), Color(0xFF123C53).copy(alpha = .55f), Color.Transparent)), CircleShape), contentAlignment = Alignment.Center) {
            Box(Modifier.size(88.dp).background(Brush.radialGradient(listOf(Color.White.copy(alpha = .72f), tint, Color(0xFF071723))), CircleShape))
            Box(Modifier.size(110.dp).padding(5.dp).background(Color.Transparent, CircleShape))
        }
        Spacer(Modifier.height(8.dp)); Text(mode.name, color = tint, fontSize = 9.sp, letterSpacing = 2.sp)
    }
}

private fun loadLines(raw: String): List<Line> = try {
    val array = org.json.JSONArray(raw); (0 until array.length()).map { index -> val item = array.getJSONObject(index); Line(item.optString("role"), item.optString("text")) }
} catch (_: Exception) { emptyList() }
