# Backend seguro J.A.R.V.I.S.

Requer Node.js 20+ e uma chave emitida pelo provedor escolhido. A chave **não** deve ser enviada ao APK, versionada no Git ou incluída em logs.

```sh
cd backend
export AI_API_KEY='sua-chave-fornecida-pelo-provedor'
export AI_MODEL='gpt-4o-mini'
export PORT=8787
node server.mjs
```

`AI_API_KEY` é lida somente pelo processo do servidor. `AI_CHAT_COMPLETIONS_URL` pode ser usada para endpoint compatível com Chat Completions. Em produção, restrinja `ALLOWED_ORIGIN`, coloque o serviço atrás de HTTPS e configure autenticação/rate limiting no gateway; não exponha diretamente uma instância sem controles de abuso. A chave ilustrativa acima é só um valor local temporário: prefira um secret manager do provedor de hospedagem.

Teste de saúde funcional (com backend e chave configurados):

```sh
curl -i http://localhost:8787/chat -H 'content-type: application/json' \
  -d '{"messages":[{"role":"user","content":"Responda apenas: teste"}]}'
```

O aplicativo aceita apenas URL HTTPS para backend. Para teste em aparelho, publique o serviço em um host HTTPS confiável. Não use `10.0.2.2` para o Redmi físico; esse endereço só é especial no emulador Android. CORS não substitui autenticação.
