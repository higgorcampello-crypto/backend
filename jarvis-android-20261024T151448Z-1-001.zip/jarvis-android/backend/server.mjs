import http from 'node:http';

const port = Number(process.env.PORT || 8787);
const apiKey = process.env.AI_API_KEY;
const endpoint = process.env.AI_CHAT_COMPLETIONS_URL || 'https://api.openai.com/v1/chat/completions';
const model = process.env.AI_MODEL || 'gpt-4o-mini';
const allowedOrigin = process.env.ALLOWED_ORIGIN || '*';
const maxBody = 64 * 1024;

function send(res, status, payload) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'access-control-allow-origin': allowedOrigin, 'access-control-allow-methods': 'POST, OPTIONS', 'access-control-allow-headers': 'content-type' });
  res.end(JSON.stringify(payload));
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') { res.writeHead(204, { 'access-control-allow-origin': allowedOrigin, 'access-control-allow-methods': 'POST, OPTIONS', 'access-control-allow-headers': 'content-type' }); return res.end(); }
  if (req.method !== 'POST' || req.url !== '/chat') return send(res, 404, { error: 'Rota não encontrada.' });
  if (!apiKey) return send(res, 503, { error: 'Backend sem configuração: defina AI_API_KEY no servidor.' });
  let data = '';
  for await (const chunk of req) { data += chunk; if (data.length > maxBody) return send(res, 413, { error: 'Mensagem excede o limite permitido.' }); }
  try {
    const input = JSON.parse(data);
    if (!Array.isArray(input.messages) || input.messages.length < 1 || input.messages.length > 20) return send(res, 400, { error: 'Campo messages inválido.' });
    const messages = input.messages.map(({ role, content }) => {
      if (!['user', 'assistant'].includes(role) || typeof content !== 'string' || content.length > 8000) throw new Error('Formato de mensagem inválido.');
      return { role, content };
    });
    const upstream = await fetch(endpoint, {
      method: 'POST',
      headers: { authorization: `Bearer ${apiKey}`, 'content-type': 'application/json' },
      body: JSON.stringify({ model, messages: [{ role: 'system', content: 'Você é J.A.R.V.I.S., um assistente útil. Responda em português brasileiro, de forma concisa e segura.' }, ...messages], max_tokens: 700 }),
      signal: AbortSignal.timeout(40000)
    });
    const result = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return send(res, 502, { error: 'O provedor de IA não respondeu com sucesso. Tente novamente mais tarde.' });
    const reply = result.choices?.[0]?.message?.content?.trim();
    if (!reply) return send(res, 502, { error: 'O provedor retornou resposta vazia.' });
    return send(res, 200, { reply });
  } catch (err) {
    const message = err instanceof SyntaxError ? 'JSON inválido.' : (err.name === 'TimeoutError' ? 'Tempo limite do provedor excedido.' : err.message);
    return send(res, 400, { error: message || 'Falha ao processar solicitação.' });
  }
});

server.listen(port, '0.0.0.0', () => console.log(`JARVIS backend ouvindo na porta ${port}`));
