# J.A.R.V.I.S. — Android nativo

Aplicativo Android nativo em Kotlin e Jetpack Compose, com foco em telas compactas, tema escuro, acentos ciano, núcleo animado, conversa por texto/voz e conexão a backend HTTPS. `minSdk 26`, `targetSdk 35`; o Redmi Note 11 é compatível. O APK ainda precisa ser compilado em um ambiente com Android SDK.

## O que está implementado

- Interface adaptativa em Compose com núcleo pulsante que diferencia espera, escuta, processamento, fala e erro.
- Entrada por texto e reconhecimento de fala em `pt-BR` usando `SpeechRecognizer`; o microfone só é solicitado ao tocar em **FALAR**. Há controle explícito para cancelar a escuta.
- Respostas faladas com `TextToSpeech` em português brasileiro e botão para interromper a fala. A voz instalada no aparelho pode variar; recursos de síntese e reconhecimento podem exigir serviço de sistema e internet.
- Histórico apenas em memória por padrão. A opção de persistência local só fica ativa após opt-in em Configurações e pode ser desativada; **LIMPAR** apaga as conversas deste aparelho.
- Backend configurável no app, somente por URL HTTPS. Nenhuma chave de provedor é armazenada no aplicativo.
- Mensagens de configuração ausente, permissão negada, falha de rede e backend indisponível.

## Compilar APK debug

1. Instale Android Studio atual com Android SDK Platform 35, Build Tools compatíveis e JDK 17.
2. Abra esta pasta (`jarvis-android`) no Android Studio e aguarde a sincronização Gradle. Não há wrapper Gradle neste pacote; deixe o Android Studio usar seu Gradle compatível, ou execute por uma instalação local do Gradle 8.9+.
3. Execute `./gradlew test` se gerar wrapper compatível, ou `gradle :app:testDebugUnitTest`.
4. Gere via **Build > Build Bundle(s) / APK(s) > Build APK(s)**. APK debug: `app/build/outputs/apk/debug/app-debug.apk`.

Pela linha de comando, com SDK configurado e Gradle instalado:

```sh
export ANDROID_HOME="$HOME/Android/Sdk"
export PATH="$PATH:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin"
gradle :app:testDebugUnitTest :app:assembleDebug
```

Para distribuição, gere APK assinado em **Build > Generate Signed Bundle / APK** e mantenha a chave privada de assinatura fora do repositório. Não use um APK debug em distribuição pública.

## Configurar e instalar no Redmi Note 11

1. Implante o backend seguindo [`backend/README.md`](backend/README.md), com HTTPS público e a chave definida como segredo no servidor.
2. No app, abra **CONFIG**, insira a URL base do backend (por exemplo `https://assistente.seudominio.com`) e salve. O cliente chamará `/chat`.
3. Ative transferência USB no aparelho: Configurações > Sobre o telefone > toque repetidamente em versão MIUI/HyperOS para habilitar opções do desenvolvedor; depois habilite Depuração USB. Os nomes de menus podem variar pela versão MIUI.
4. Conecte o aparelho, autorize o computador na caixa de diálogo e execute `adb devices` para verificar que consta `device`.
5. Instale: `adb install -r app/build/outputs/apk/debug/app-debug.apk`. Alternativamente, copie o APK para o telefone e autorize instalação da origem de arquivos usada.
6. No app, teste primeiro texto com o backend disponível; toque em **FALAR** e conceda microfone apenas quando solicitado; diga uma frase em português. Use **CANCELAR ESCUTA**, **PARAR FALA** e **LIMPAR** para verificar controles de interrupção e privacidade.

## Testes e limitações conhecidas

- Testes unitários verificam que endpoint ausente ou não HTTPS é rejeitado. Backend pode ser verificado com o `curl` descrito em `backend/README.md`.
- A máquina de desenvolvimento usada para esta entrega não possui Android SDK, `adb` ou Gradle detectáveis; portanto, não foi possível executar compilação, instalar em aparelho ou afirmar que esses testes passaram neste ambiente. Faça build e teste em Android Studio com SDK instalado.
- A URL HTTPS configurada no cliente não oferece autenticação de usuário por si só. Em produção, acrescente autenticação e limites de uso no gateway. Não embuta credenciais do provedor no app.
- Fase entregue: interface, voz e proxy para IA. Atalhos, integração de comandos Android e ativação avançada não estão habilitados; requerem desenho separado de permissões e confirmação antes de qualquer ação externa.

## Estrutura

```text
app/src/main/                     interface Compose, voz e atividade Android
app/src/main/java/.../data/       cliente HTTPS do serviço
app/src/test/                     testes unitários
backend/server.mjs                proxy Node.js com segredo no servidor
backend/README.md                 configuração do backend
```
